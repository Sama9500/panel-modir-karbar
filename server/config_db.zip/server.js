
const express = require("express")
const cors = require("cors")
const dotenv = require("dotenv")
const rahandaziDb = require("./config_db") // این فایل باید نسخه MySQL باشه

const routeVorood = require("./routes/route_vorood")
const routeSabtenam = require("./routes/route_sabtenam")
const routeDashboard = require("./routes/route_dashboard")
const routeModir = require("./routes/route_modir")

dotenv.config()

const app = express()

app.use(cors())
app.use(express.json())

// اتصال به دیتابیس MySQL
rahandaziDb()

app.get("/", (req, res) => {
  res.json({ payam: "api faal ast" })
})

app.use("/vorood", routeVorood)
app.use("/sabtenam", routeSabtenam)
app.use("/dashboard", routeDashboard)
app.use("/modir", routeModir)

const port = process.env.PORT || 5000
app.listen(port, () => {
  console.log(`server dar port ${port} dar hal ejra ast`)
})
