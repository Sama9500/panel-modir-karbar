
const jwt = require("jsonwebtoken")
const rahandaziDb = require("./rahandaziDb") // فایل اتصال به MySQL

async function middlewareAuth(req, res, next) {
  const sarcheshme = req.headers.authorization || ""
  const gheta = sarcheshme.split(" ")
  const token = gheta.length === 2 ? gheta[1] : null

  if (!token) {
    return res.status(401).json({ message: "توکن یافت نشد" })
  }

  try {
    const kodGoshay = jwt.verify(token, process.env.JWT_SECRET)
    req.karbarId = kodGoshay.karbarId
    req.role = kodGoshay.role

    // بررسی وجود کاربر در MySQL
    const db = await rahandaziDb()
    const karbar = await db.findByEmail(kodGoshay.email) // یا بر اساس id اگر متدش رو اضافه کنیم

    if (!karbar) {
      return res.status(401).json({ message: "کاربر معتبر نیست" })
    }

    next()
  } catch (err) {
    return res.status(401).json({ message: "توکن نامعتبر است" })
  }
}

module.exports = middlewareAuth
