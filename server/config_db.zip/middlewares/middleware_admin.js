
const rahandaziDb = require("./rahandaziDb") // فایل اتصال به MySQL

async function middlewareAdmin(req, res, next) {
  try {
    const db = await rahandaziDb()
    const karbar = await db.findById(req.karbarId)

    if (!karbar) {
      return res.status(403).json({ message: "کاربر یافت نشد" })
    }

    if (karbar.role !== "admin") {
      return res.status(403).json({ message: "دسترسی غیر مجاز است" })
    }

    next()
  } catch (err) {
    return res.status(500).json({ message: "خطا در بررسی نقش کاربر" })
  }
}

module.exports = middlewareAdmin
