
const mysql = require("mysql2/promise");

async function rahandaziDb() {
  const config = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
  };

  try {
    // ایجاد pool برای مدیریت اتصال‌ها
    const pool = mysql.createPool(config);

    // ساخت جدول اگر وجود نداشت
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS karbar (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        ramzHashed VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'user',
        status VARCHAR(50) DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    console.log("ارتباط با MySQL برقرار شد و جدول karbar آماده است");

    // آبجکت برای کار با جدول
    const ModelKarbar = {
      async insert(email, ramzHashed, role = "user", status = "active") {
        const [result] = await pool.execute(
          "INSERT INTO karbar (email, ramzHashed, role, status) VALUES (?, ?, ?, ?)",
          [email, ramzHashed, role, status]
        );
        return result.insertId;
      },

      async findByEmail(email) {
        const [rows] = await pool.execute(
          "SELECT * FROM karbar WHERE email = ?",
          [email]
        );
        return rows[0];
      },

      async findAll() {
        const [rows] = await pool.execute("SELECT * FROM karbar");
        return rows;
      }
    };

    return ModelKarbar;
  } catch (err) {
    console.error("ارتباط با MySQL ممکن نشد:", err.message);
    process.exit(1);
  }
}

module.exports = rahandaziDb;
