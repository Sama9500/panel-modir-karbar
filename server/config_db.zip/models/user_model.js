
const mysql = require("mysql2/promise")

async function ModelKarbar() {
  const config = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
  }

  try {
    const connection = await mysql.createConnection(config)

    // ساخت جدول karbar اگر وجود نداشت
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS karbar (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        ramzHashed VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'user',
        status VARCHAR(50) DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `)

    console.log("جدول karbar در MySQL آماده است")

    // آبجکت برای کار با جدول
    return {
      async insert(email, ramzHashed, role = "user", status = "active") {
        const [result] = await connection.execute(
          "INSERT INTO karbar (email, ramzHashed, role, status) VALUES (?, ?, ?, ?)",
          [email, ramzHashed, role, status]
        )
        return result.insertId
      },

      async findByEmail(email) {
        const [rows] = await connection.execute(
          "SELECT * FROM karbar WHERE email = ?",
          [email]
        )
        return rows[0]
      },

      async findAll() {
        const [rows] = await connection.execute("SELECT * FROM karbar")
        return rows
      },

      async updateStatus(id, newStatus) {
        await connection.execute(
          "UPDATE karbar SET status = ? WHERE id = ?",
          [newStatus, id]
        )
        return true
      },

      async deleteById(id) {
        await connection.execute("DELETE FROM karbar WHERE id = ?", [id])
        return true
      }
    }
  } catch (err) {
    console.log("ارتباط با MySQL یا ساخت جدول karbar ممکن نشد", err)
    process.exit(1)
  }
}

module.exports = ModelKarbar
