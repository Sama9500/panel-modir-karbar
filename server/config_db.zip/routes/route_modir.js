
const express = require("express")
const { voroodModir, taghirRole, taghirVaziyat } = require("../controllers/controller_modir")
const router = express.Router()

router.post("/", voroodModir)
router.post("/taghir-role", taghirRole)
router.post("/taghir-vaziyat", taghirVaziyat)

module.exports = router
