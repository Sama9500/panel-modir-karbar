
const express = require("express")
const { voroodKarbar } = require("../controllers/controller_vorood")

const router = express.Router()

router.post("/", voroodKarbar)

module.exports = router
