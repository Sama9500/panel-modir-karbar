
const express = require("express")
const { sabtenamKarbar } = require("../controllers/controller_sabtenam")

const router = express.Router()

// مسیر ثبت‌نام کاربر
router.post("/", sabtenamKarbar)

module.exports = router
