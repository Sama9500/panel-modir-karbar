
const express = require("express")
const { daryaftEtelaatDashboard } = require("../controllers/controller_dashboard")
const middlewareAuth = require("../middlewares/middleware_auth")

const router = express.Router()

router.post("/", middlewareAuth, daryaftEtelaatDashboard)

module.exports = router
