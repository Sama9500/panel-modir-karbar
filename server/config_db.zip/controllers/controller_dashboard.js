
const rahandaziDb = require("../models/user_model") // فایل مدل MySQL که جدول karbar رو می‌سازه و متدها رو برمی‌گردونه

async function daryaftEtelaatDashboard(req, res) {
  try {
    const ModelKarbar = await rahandaziDb()

    // گرفتن اطلاعات کاربر از MySQL با متد findById
    const karbar = await ModelKarbar.findById(req.karbarId)

    if (!karbar) {
      return res.status(404).json({ message: "کاربر یافت نشد" })
    }

    // فقط ستون‌های مورد نیاز رو برگردونیم
    const karbarInfo = {
      email: karbar.email,
      role: karbar.role,
      status: karbar.status,
      created_at: karbar.created_at
    }

    // فعالیت‌های نمونه (می‌تونی بعداً از دیتابیس هم بیاری)
    const faaliyatHa = [
      { onvan: "ورود به حساب", tarikh: new Date() },
      { onvan: "مشاهده تنظیمات", tarikh: new Date() }
    ]

    return res.status(200).json({ karbar: karbarInfo, faaliyatHa })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ message: "خطای داخلی سرور" })
  }
}

module.exports = { daryaftEtelaatDashboard }
