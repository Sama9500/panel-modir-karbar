
const rahandaziDb = require("../models/user_model") // فایل مدل MySQL که جدول karbar رو می‌سازه و متدها رو برمی‌گردونه

// ورود مدیر
async function voroodModir(req, res) {
  try {
    const { ramz } = req.body
    const ramzSahih = process.env.ADMIN_SECRET

    if (!ramz) {
      return res.status(400).json({ message: "رمز مدیر الزامی است" })
    }

    if (ramz !== ramzSahih) {
      return res.status(401).json({ message: "رمز مدیر اشتباه است" })
    }

    const ModelKarbar = await rahandaziDb()
    const users = await ModelKarbar.findAll() // گرفتن همه کاربران از MySQL

    // فقط ستون‌های مورد نیاز رو برگردونیم
    const usersMapped = users.map(u => ({
      email: u.email,
      role: u.role,
      status: u.status,
      created_at: u.created_at
    }))

    return res.status(200).json({ message: "ورود مدیر موفق", users: usersMapped })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ message: "خطای داخلی سرور" })
  }
}

// تغییر نقش کاربر
async function taghirRole(req, res) {
  try {
    const { karbarId, roleJadid } = req.body
    const ModelKarbar = await rahandaziDb()

    const karbar = await ModelKarbar.findById(karbarId) // استفاده از متد findById
    if (!karbar) {
      return res.status(404).json({ message: "کاربر یافت نشد" })
    }

    await ModelKarbar.updateRole(karbarId, roleJadid || "user")
    return res.status(200).json({ message: "نقش کاربر تغییر کرد" })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ message: "خطای داخلی سرور" })
  }
}

// تغییر وضعیت کاربر
async function taghirVaziyat(req, res) {
  try {
    const { karbarId, vaziyatJadid } = req.body
    const ModelKarbar = await rahandaziDb()

    const karbar = await ModelKarbar.findById(karbarId)
    if (!karbar) {
      return res.status(404).json({ message: "کاربر یافت نشد" })
    }

    await ModelKarbar.updateStatus(karbarId, vaziyatJadid || "active")
    return res.status(200).json({ message: "وضعیت کاربر تغییر کرد" })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ message: "خطای داخلی سرور" })
  }
}

module.exports = { voroodModir, taghirRole, taghirVaziyat }
