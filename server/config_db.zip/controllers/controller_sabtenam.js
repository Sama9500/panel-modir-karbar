
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const rahandaziDb = require("../models/user_model") // فایل مدل کاربر

async function sabtenamKarbar(req, res) {
  try {
    const { email, ramzOboor } = req.body

    if (!email || !ramzOboor) {
      return res.status(400).json({ message: "ایمیل و رمز عبور الزامی است" })
    }

    // اتصال به مدل MySQL
    const ModelKarbar = await rahandaziDb()

    // بررسی وجود کاربر
    const vojod = await ModelKarbar.findByEmail(email)
    if (vojod) {
      return res.status(409).json({ message: "این ایمیل قبلاً ثبت شده است" })
    }

    // بررسی طول رمز
    if (ramzOboor.length < 6) {
      return res.status(400).json({ message: "رمز عبور باید حداقل 6 کاراکتر باشد" })
    }

    // هش کردن رمز
    const namak = await bcrypt.genSalt(10)
    const ramzHashed = await bcrypt.hash(ramzOboor, namak)

    // ذخیره کاربر جدید در MySQL
    const jadidId = await ModelKarbar.insert(email, ramzHashed, "user", "active")

    // گرفتن کاربر ذخیره‌شده برای ساخت توکن
    const jadid = await ModelKarbar.findByEmail(email)

    // ساخت توکن JWT
    const token = jwt.sign(
      { karbarId: jadid.id, role: jadid.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    )

    if (!token) {
      return res.status(500).json({ message: "توکن ایجاد نشد" })
    }

    return res.status(201).json({ message: "ثبت‌نام موفق", token })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ message: "خطای داخلی سرور" })
  }
}

module.exports = { sabtenamKarbar }
