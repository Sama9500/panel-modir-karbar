
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const rahandaziDb = require("../models/user_model") // فایل مدل کاربر

async function voroodKarbar(req, res) {
  try {
    const { email, ramzOboor } = req.body

    if (!email || !ramzOboor) {
      return res.status(400).json({ message: "ایمیل و رمز عبور الزامی است" })
    }

    // اتصال به مدل MySQL
    const ModelKarbar = await rahandaziDb()

    // پیدا کردن کاربر با ایمیل
    const karbar = await ModelKarbar.findByEmail(email)
    if (!karbar) {
      return res.status(404).json({ message: "کاربر یافت نشد، لطفاً ثبت‌نام کنید" })
    }

    // بررسی رمز عبور
    const sahih = await bcrypt.compare(ramzOboor, karbar.ramzHashed)
    if (!sahih) {
      return res.status(401).json({ message: "رمز عبور نادرست است" })
    }

    // ساخت توکن JWT
    const token = jwt.sign(
      { karbarId: karbar.id, role: karbar.role }, // در MySQL کلید اصلی id است
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    )

    if (!token) {
      return res.status(500).json({ message: "توکن ایجاد نشد" })
    }

    return res.status(200).json({ message: "ورود موفق", token })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ message: "خطای داخلی سرور" })
  }
}

module.exports = { voroodKarbar }
